package org.firstinspires.ftc.teamcode.Pirates_Of_The_Grind_Island_10841_team_code;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

/**
 * Created by Luke on 12/4/2016.
 */
@Autonomous(name = "line tracking")
//@Disabled
public class LineTracking  extends LinearOpMode {
    Team_10841_Robot robot =new Team_10841_Robot();

    double Floor_odsRawValue;
    double Wall_odsRawValue;
    static double odsReading;

    boolean DriveToBeacon_Complete = false;
    boolean PressBeacon_Complete = false;

    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap);

        waitForStart();

        while (opModeIsActive()) {
//            robot.left_color.enableLed(true);
//            robot.right_color.enableLed(true);
            telemetry.addData("ODS distance from wall raw reading", "%4.4f", robot.ods_Wall.getRawLightDetected())
                    .addData("ODS line raw reading", "%4.4f", robot.ods_Wall.getRawLightDetected())
                    .addData("left color", robot.left_color)
                    .addData("right color", robot.right_color);
            telemetry.update();

            //********** start of "drive ot beacon" *********//
//            if (driveToBeacon() && !PressBeacon_Complete && DriveToBeacon_Complete) { // if driveToBeacon has not run...
//                PressBeacon_Complete = false;
//                DriveToBeacon_Complete = true;
      //          driveToBeacon(); // run driveToBeacon
//            } //else DriveToBeacon_Complete = true;
            //********** end of "drive to beacon" start of "press beacon" **********//
//            if (pressBeacon()&& !PressBeacon_Complete && DriveToBeacon_Complete) { // if pressBeacon has not run...
//                PressBeacon_Complete = true;
//                DriveToBeacon_Complete = false;
//                pressBeacon(); // run pressBeacon
//            } //else DriveToBeacon_Complete = false;
            //********** end of "press beacon" start of "line following" **********//

//            telemetry.addData("ods Reading", robot.ods_Line);
//            telemetry.update();

//            lineTracking();
//            if (/*driveToBeacon() &&*/ pressBeacon());
//                else{ sleep(5000); break;}
//
//            waitOneFullHardwareCycle();
        }
    }

    void driveToBeacon(){
        if (robot.ods_Wall.getRawLightDetected() < 0.5) {
            robot.leftDriveMotor.setPower(-0.1);
            robot.rightDriveMotor.setPower(-0.1);
        }else {
            robot.leftDriveMotor.setPower(0.0);
            robot.rightDriveMotor.setPower(0.0);
        }
    }

    boolean pressBeacon(){
        if (robot.left_color.blue() > robot.left_color.red() && robot.left_color.blue() > robot.left_color.green()) {
            robot.leftDriveMotor.setPower(-0.1);
            robot.rightDriveMotor.setPower(0.0);
        }else  if (robot.left_color.red() > robot.left_color.blue() && robot.left_color.red() > robot.left_color.green()){
            robot.leftDriveMotor.setPower(0.0);
            robot.rightDriveMotor.setPower(-0.1);
        } else {
            robot.leftDriveMotor.setPower(0.0);
            robot.rightDriveMotor.setPower(0.0);
        }
        if (robot.leftDriveMotor.isBusy() && robot.rightDriveMotor.isBusy()) return false;
        else return true;
    }

    void lineTracking(){

        // Display weather the ODS sees the foam tile or the white line.
        if (robot.ods_Line.getRawLightDetected() > 0.2)
            telemetry.addLine("white line");
        else telemetry.addLine("foam tile");
        telemetry.update();

        while (robot.ods_Wall.getRawLightDetected() < 0.5) // robot is less than ~4cm from beacon
            if (robot.ods_Line.getRawLightDetected() < 0.2) { // ods sees foam
                robot.leftDriveMotor.setPower(-0.01);
                robot.rightDriveMotor.setPower(-0.1);
            } else { // ods sees white line
                robot.leftDriveMotor.setPower(-0.1);
                robot.rightDriveMotor.setPower(-0.01);
            }
    }
}
