package org.firstinspires.ftc.teamcode.Pirates_Of_The_Grind_Island_10841_team_code;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

import static java.lang.Thread.sleep;

/**
 * Created by Luke on 11/11/2016.
 */

@TeleOp(name = "TeleOp (This One!!!)", group = "PGI_10841")
//@Disabled
public class twoSpeedTeleOp extends LinearOpMode{
    Team_10841_Robot robot  =new Team_10841_Robot();  //use Team_10841_Robot hardware

    boolean  _high_speed  = false;             // Servo mid position
    boolean _right_bumper_state;                // keep track if the button state has changed
    double left;                               // current calculated left motor speed from gamepad1.left_stick
    double right;                              // current calculated right motor speed from gamepad1.left_stick
    double intake;                             // intake motor from gamepad2.left_stick
    int CatapultTicksPerLaunch = (256 * 28);  // gear reduction 256:1 * Motor ticks per revolution



    //start of program
    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap);    //initialise Team_10841_Robot's hardware map
        _right_bumper_state = gamepad1.right_bumper;  // initialize the bumper state

        robot.rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        robot.leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        robot.intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        robot.leftDriveMotor.setPower(0.0);
        robot.rightDriveMotor.setPower(0.0);
        robot.intake.setPower(0.0);
        // Send telemetry message to signify robot waiting
        telemetry.addData("right drive", robot.rightDriveMotor.getCurrentPosition());
        telemetry.addData("left drive", robot.leftDriveMotor.getCurrentPosition());

        /*wait for start button to be pressed*/
        waitForStart();

        /*loop until stop button is pressed*/
        while (opModeIsActive()) {
            /* -------------- Drive Motor Control --------------------------------------------------
            Left and right drive motors are controlled in this section.  The calculations are to make
            the joystick less responsive to give the operator more control
            */

            // Run wheels in Arcade mode (note: The joystick goes negative when pushed forwards, so negate it)


             /*  --------------- intake motor control ----------------------------------------------
              Could use the second gamepad to control the intake so the driver will not be conserned with
              watching the intake. The left joystick will control if the intake is accepting or rejecting
              the current game particle.  Allows for a second driver.  This is also placed on gamepad1
              for a single operator
             */

            twoSpeed();  // set the game driver joystick in high or low speed.
            intake = (-gamepad1.right_stick_y);
            robot.intake.setPower(intake);

            if (gamepad1.left_bumper && robot.catapultIdle) {  // driver initiated ball launch
                robot.StartCatapultCycle();
            }

            if (robot.catapultCalibrate.isPressed()) {  // end of catapult cycle, loads the next ball.
                robot.EndCatapultCycle();
            }

            /*
             * x button is to load ball if we have fired all the balls and the catapult is ready to
             * fire a ball is not in position
             */
            if (gamepad1.x && robot.catapultIdle) {
                robot.loadBall();
            }

            /*
             * red button B is in case we have problems with the catapultCalibrate switch.
             * This is a manual override to tell the catapult it can reload, hopefully at the
             * bottom of the stroke.
             */
            if (gamepad1.b && !robot.catapultIdle) {
                robot.EndCatapultCycle();
            }

            /*
             * left trigger raises the ball lift, the right trigger lowers the lift
             */
            if (gamepad1.right_trigger > 0.001) {
                robot.ballLift(gamepad1.left_trigger);
            }
            if (gamepad1.left_trigger > 0.001) {
                robot.ballLift(-gamepad1.right_trigger);
            }

                // Send telemetry message to signify robot running;
            telemetry.addData("left", left);
            telemetry.addData("right", right);
            telemetry.addData("intake", intake);
            telemetry.addData("StartCatapultFunction position", robot.catapult.getCurrentPosition());
            telemetry.addData("Button Pressed",robot.catapultCalibrate.isPressed());
            if (_high_speed) {
                telemetry.addData("Speed", "High");
            } else {
                telemetry.addData("Spebed", "Low");
            }
            updateTelemetry(telemetry);
        }
    }

    public void twoSpeed(){
        left = (-robot.JoystickToMotorVal(gamepad1.left_stick_y)) + (robot.JoystickToMotorVal(gamepad1.left_stick_x)/3);  // we divide the x axis so left and right respond less to the joystick
        right = (-robot.JoystickToMotorVal(gamepad1.left_stick_y)) - (robot.JoystickToMotorVal(gamepad1.left_stick_x)/3);
        if (_high_speed) {
            robot.leftDriveMotor.setPower(left);
            robot.rightDriveMotor.setPower(right);
        } else {
            robot.leftDriveMotor.setPower(left / 4);
            robot.rightDriveMotor.setPower(right /4);
        }
        // determine if low speed button has been pressed to switch to low or high speed motor control
        if (_right_bumper_state=gamepad1.right_bumper) {
            if (gamepad1.right_bumper) {
                _high_speed = !_high_speed;
            }
            _right_bumper_state=gamepad1.right_bumper;
        }
    }
//    void StartCatapultCycle() throws InterruptedException {
//        catapultIdle = false;
//        robot.catapult.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//        robot.catapult.setPower(1.0);
//        while (robot.catapultCalibrate .isPressed()){} // do nothing!!
//         sleep(1000);
//    }
//    void EndCatapultCycle() throws InterruptedException {
//        if (!catapultIdle) {
//            robot.catapult.setPower(0.0);
//            loadBall(); // load the ball onto the catapult arm
//            catapultIdle = true;
//        }
//    }
//    void loadBall() throws InterruptedException {
//        robot.ballPusher.setPosition(0.0);
//        sleep(500);
//        robot.ballPusher.setPosition(1.0);
//    }

}
