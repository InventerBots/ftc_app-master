package org.firstinspires.ftc.teamcode.Pirates_Of_The_Grind_Island_10841_team_code;

import com.qualcomm.hardware.modernrobotics.ModernRoboticsAnalogOpticalDistanceSensor;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cGyro;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.TouchSensor;
import com.qualcomm.robotcore.hardware.UltrasonicSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

import static java.lang.Thread.sleep;

/**
 * This is NOT an opmode.
 * <p>
 * This class can be used to define all the specific hardware for a single robot.
 * This hardware class is for the 2016-17 Velocity Vortex 10841 robot.
 * <p>
 * This hardware class assumes the following device names have been configured on the robot:
 * <p>
 * Motor channel 1:  Left  drive motor a :        "left motor a"
 * Motor channel 2:  Right drive motor a:         "right motor a"
 * Motor channel 3:  Intake motor :               "intake motor"
 * Motor channel 4:  Catapult motor :             "catapult motor"
 */
class Team_10841_Robot {
    /* calculations parameters
     * gear ratio: motor = 20t wheel = 18t = 1:0.9
     * ticks per motor revolution = 28
     * motor gear reduction = 16:1
     */
    public static final double driveWheelTicksPerRevolution = (0.9 * 28 * 16);
    /*  Wheel diameter is 3 inches
     * the circumference is (3 * PI) inches
     * so ticks per inch is driveWheelTicksPerRevolution / circumference
     */
    public static final double driveWheelTicksPerInch = driveWheelTicksPerRevolution / (Math.PI * 3);
    /* Public Autonomous_color_sensing_OpMode members. */

    boolean catapultIdle = true;               // true = catapult is waiting for the launch command

    // motors
    public DcMotor leftDriveMotor = null;
    public DcMotor rightDriveMotor = null;
    public DcMotor intake = null;
    public DcMotor catapult = null;
    public DcMotor liftmotor = null;
    // servo
    public Servo ballPusher = null;

    // touch sensor
    public TouchSensor catapultCalibrate;

    // ultrasonic sensors
    public UltrasonicSensor right_sonar;
    public UltrasonicSensor left_sonar;

    // optical distance sensors
    public ModernRoboticsAnalogOpticalDistanceSensor ods_Line;
    public ModernRoboticsAnalogOpticalDistanceSensor ods_Wall;

    // color sensors
    public ColorSensor left_color;
    public ColorSensor right_color;

    // gyro sensor
    public ModernRoboticsI2cGyro gyro;



    double maxDrivePower = 0.4;
    double drivePower;
    double stop = 0.0;
    int zAccumulated;  //Total rotation left/right
    int ticksToMove;
    int slowZone = setTargetInches(16.0);
    int currentRotation;
    int wallDistance;
    double left_sonar_Value;
    double right_sonar_Value;
    double odsValue;
    boolean firstBeaconSuccess;
    boolean secondBeaconSuccess;
//    boolean initGyro = false;

    /* Local Autonomous_color_sensing_OpMode members. */
    HardwareMap hwMap = null;
    private ElapsedTime period = new ElapsedTime();


    /* Constructor */
    public Team_10841_Robot() {
    }

    /*
    * Change the joystick value to a curve value instead of a linear value
    */

    public double JoystickToMotorVal(double xyVal) {
        double v = Math.pow((xyVal * 100), 3) / 1000000;
        return v;
    }

    /* Initialize standard Hardware interfaces */
    public void init(HardwareMap ahwMap) throws InterruptedException {
        // save reference to HW Map
        hwMap = ahwMap;


        // Define and Initialize the Motors
        leftDriveMotor = hwMap.dcMotor.get("left drive");
        rightDriveMotor = hwMap.dcMotor.get("right drive");
        intake = hwMap.dcMotor.get("intake motor");
        catapult = hwMap.dcMotor.get("catapult");
        liftmotor = hwMap.dcMotor.get("lift motor");

        // Define and Initialize the Servo

        ballPusher = hwMap.servo.get("color servo");

        // Define and Initialize the Touch Sensor
        catapultCalibrate = hwMap.touchSensor.get("cat touch");

        // Define and Initialize the Ultrasonic Sensors
        left_sonar = hwMap.ultrasonicSensor.get("left sonar");
        right_sonar = hwMap.ultrasonicSensor.get("right sonar");

        // Define and Initialize the Optical Distance Sensor
        ods_Line = (ModernRoboticsAnalogOpticalDistanceSensor) hwMap.opticalDistanceSensor.get("ods line");
        ods_Wall = (ModernRoboticsAnalogOpticalDistanceSensor) hwMap.opticalDistanceSensor.get("ods wall");

        // Define and Initialize the Color Sensors

        left_color = hwMap.colorSensor.get("left color");
        I2cAddr left_color_addr = I2cAddr.create8bit(0x3a);
        left_color.setI2cAddress(left_color_addr);
        left_color.enableLed(false);

        right_color = hwMap.colorSensor.get("right color");
        I2cAddr right_color_addr = I2cAddr.create8bit(0x3c);
        right_color.setI2cAddress(right_color_addr);
        right_color.enableLed(false);

        // Define and Initialize the Gyro Sensor
        gyro = (ModernRoboticsI2cGyro) hwMap.gyroSensor.get("gyro");
//        I2cAddr gyro_addr = I2cAddr.create8bit(0x20);
//        gyro.setI2cAddress(gyro_addr);

//        if (initGyro) {
            // get a reference to a Modern Robotics GyroSensor object.
            gyro.calibrate();

            // make sure the gyro is calibrated.
            while (gyro.isCalibrating()) {
                Thread.sleep(50);
            }
//        }


        // Reverse the Left Drive Motor for operator drive mode
        SetAutonomousMode(false);

        // Stop the Motors
        leftDriveMotor.setPower(0.0);
        rightDriveMotor.setPower(0.0);
        intake.setPower(0.0);
        catapult.setPower(0.0);
        liftmotor.setPower(0.0);

        //ballPusher.setPosition(0.5);

        // Set the Run Mode of the drive and catapult
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        catapult.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Set the Run Mode of the intake motor
        intake.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }
    void ballLift(double power){
        liftmotor.setPower(Range.clip(power,-1.0,1.0));
    }
    void SetAutonomousMode(boolean AutonomusMode){
    if(AutonomusMode) {
        leftDriveMotor.setDirection(DcMotor.Direction.FORWARD);
        rightDriveMotor.setDirection(DcMotor.Direction.REVERSE);
    }
        else {
        leftDriveMotor.setDirection(DcMotor.Direction.REVERSE);
        rightDriveMotor.setDirection(DcMotor.Direction.FORWARD);

    }

    }
    void StartCatapultCycle() throws InterruptedException {
        catapultIdle = false;
        catapult.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        catapult.setPower(1.0);
        while (catapultCalibrate .isPressed()){} // do nothing!!
        // sleep(1000);
    }
    void EndCatapultCycle() throws InterruptedException {
        if (!catapultIdle) {
            catapult.setPower(0.0);
            loadBall(); // load the ball onto the catapult arm
            catapultIdle = true;
        }
    }
    void loadBall() throws InterruptedException {
        ballPusher.setPosition(0.0);
        sleep(500);
        ballPusher.setPosition(1.0);
    }

 /*
  * This procedure will drive the robot using 2 lego ultrasonic sensors.  It calculates the distance
  * the robot is from the wall and subtracts the distance
  *
  * ************************************************************************************************
  * We found out you cannot have two sensors of this type in the same room.  The sensors Interfere
  * with each other making them useless.  With better sensors, this may work.
  * ************************************************************************************************
  */
    void driveUsingDuelUltrasonicSensors(double distanceFromWall_In_cm, double speed) throws InterruptedException {
        left_sonar_Value = setTargetInches(getLeftUltrasonicSensorValue()-distanceFromWall_In_cm);
        right_sonar_Value = setTargetInches(getRightUltrasonicSensorValue()-distanceFromWall_In_cm);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        rightDriveMotor.setPower(speed);
        leftDriveMotor.setPower(speed);

        leftDriveMotor.setTargetPosition(leftDriveMotor.getCurrentPosition() - (int) left_sonar_Value);
        rightDriveMotor.setTargetPosition(rightDriveMotor.getCurrentPosition() - (int) right_sonar_Value);

        while (leftDriveMotor.isBusy() && rightDriveMotor.isBusy())
            sleep(10);

        sleep(100);
        rightDriveMotor.setPower(0);
        leftDriveMotor.setPower(0);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        return;
    }

    void stopDrive() {
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftDriveMotor.setTargetPosition(leftDriveMotor.getCurrentPosition());
        rightDriveMotor.setTargetPosition(rightDriveMotor.getCurrentPosition());
        leftDriveMotor.setPower(1.0);
        rightDriveMotor.setPower(1.0);
    }

    void driveToTarget(int distanceToDrive, int directionAdj) {
        driveStraightUsingGyros(distanceToDrive, 0.1, directionAdj);
    }

    void driveStraightUsingGyros(double Inches, double speed, int directionAdj) {
        double leftSpeed; //Power to feed the motors
        double rightSpeed;
        double StartSpeed = speed;
        double ClipSpeed = Range.clip(Math.abs(speed * 1.2), -1.0, 1.0);
        int StartPos = leftDriveMotor.getCurrentPosition();
        double encoderTarget = setTargetInches(Inches);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        double startz = gyro.getIntegratedZValue();
        double target = (gyro.getIntegratedZValue() + directionAdj);  //Starting direction
        double startPosition = leftDriveMotor.getCurrentPosition();  //Starting position

        double errorCorrection;

        while (leftDriveMotor.getCurrentPosition() < startPosition + encoderTarget) {  //While we have not passed out intended distance
            zAccumulated = gyro.getIntegratedZValue();  //Current direction
//            speed = setDrivePower(StartPos,robot.leftDriveMotor.getCurrentPosition(),encoderTarget,robot.setTargetInches(9),StartSpeed);


            errorCorrection = Range.clip(((zAccumulated - target) / 150), -0.2, 0.2); // max correction -

            leftSpeed = Range.clip((speed + errorCorrection),-ClipSpeed,ClipSpeed);  //Calculate speed for each side
            rightSpeed = Range.clip((speed - errorCorrection),-ClipSpeed,ClipSpeed);  //See Gyro Straight video for detailed explanation

            leftDriveMotor.setPower(leftSpeed);
            rightDriveMotor.setPower(rightSpeed);
        }
    }
    void driveToHeadingUsingGyros(double Inches, int heading, double speed) {
        double leftSpeed; //Power to feed the motors
        double rightSpeed;
        double ClipSpeed = Range.clip(Math.abs(speed * 1.2), -1.0, 1.0);

        double encoderTarget = setTargetInches(Inches);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        double startPosition = leftDriveMotor.getCurrentPosition();  //Starting position

        double errorCorrection;

        while (leftDriveMotor.getCurrentPosition() < startPosition + encoderTarget) {  //While we have not passed out intended distance
            zAccumulated = gyro.getIntegratedZValue();  //Current direction

            errorCorrection = Range.clip(((heading - zAccumulated) / 150), -0.2, 0.2); // max correction -

            leftSpeed = Range.clip((speed + errorCorrection),-ClipSpeed,ClipSpeed);  //Calculate speed for each drive motor
            rightSpeed = Range.clip((speed - errorCorrection),-ClipSpeed,ClipSpeed);

            leftDriveMotor.setPower(leftSpeed);
            rightDriveMotor.setPower(rightSpeed);
        }
    }

    double RampDown(int distToGo, int slowDistance, double minSpeed, double maxSpeed) {
        double target = (((double) distToGo / (double) slowDistance) * (maxSpeed - minSpeed)) + minSpeed;
        if (target > maxSpeed)
            return maxSpeed;
        else
            return target;
    }

    double RampUp(int distTraveled, int slowDistance, double minSpeed, double maxSpeed) {
        double target = (((double) distTraveled / (double) slowDistance) * (maxSpeed - minSpeed)) + minSpeed;
        if (target > maxSpeed)
            return maxSpeed;
        else
            return target;
    }

    double calcMaxSpeed(int rampDistance, int travelDistance, double minSpeed, double maxSpeed) {
        /*
         * this function will trim back the max speed if the distance to travel is less the the
         * ramp up/down distance.  It calculates a percentage decrease based on the percent decrease
         * in travel distance.
         */
        double calcmax;
        if ((rampDistance) < travelDistance)
            return maxSpeed;
        else
            return (((double) travelDistance) / (double) (rampDistance * 2) * (maxSpeed - minSpeed)) + minSpeed;
    }

    private double setDrivePower(int startPos, int currentPos, int targetPos, int slowDistance, double targetMaxPower) {
        /*
        We want to ramp down the power at the end of the run.
         */
        double minSpeed = 0.1;

        double drivePower;  // this value will be returned
        int totalTravelDistance = (Math.abs(targetPos - startPos));

        // Decrease the max speed if the ramp up and ramp down distances are shorter then
        // the total travel distance. Keep it on the same vector.
        double maxSpeed = calcMaxSpeed(slowDistance, targetPos - startPos, minSpeed, targetMaxPower);
        maxSpeed = targetMaxPower; // for now ignore the value we just calculated.  delete this later

        int DistanceRemaining = Math.abs(targetPos - currentPos);
        int DistanceTraveled = Math.abs(currentPos - startPos);

        drivePower = (RampUp(DistanceTraveled, slowDistance, minSpeed, maxSpeed) +
                RampDown(DistanceRemaining, slowDistance, minSpeed, maxSpeed)) / 2;

        if (targetPos < currentPos)
            drivePower = -drivePower;

        return drivePower;
    }

    void driveToBeacon(){
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        while (ods_Wall.getRawLightDetected() < 0.2) {
            if (ods_Wall.getRawLightDetected() < 0.0001){
                leftDriveMotor.setPower(0.2);
                rightDriveMotor.setPower(0.2);
            }else {
                leftDriveMotor.setPower(0.1);
                rightDriveMotor.setPower(0.1);
            }
        }
        leftDriveMotor.setPower(0.0);
        rightDriveMotor.setPower(0.0);

    }



    //-------------------- Press the red beacon button --------------------//
    boolean areBothSidesOfBeaconRed() {
        /*
        We need to check both color sensors to see if they are both red.  If not, maybe we can come
        back and press the button again.
         */
        if (leftBeaconButtonIsRed() && rightBeaconButtonIsRed()) {
            return true; // means that beacon is solid red
        } else return false; // means that beacon is not solid red
    }

    private boolean TheRightSideIsRed() {
        /*
        Check the color sensors to determine if the Right side of the beacon is red.  If it is
        return true;
        */
        if (rightBeaconButtonIsRed()) {
            return true; // if the right side of the beacon is red return true
        } else return false; // other wise return false
    }

    void pressTheRedButton() throws InterruptedException {
        /*
        Now we need to pivot the robot to the left or right depending on which side is red and drive
        forward about 10 cm.
         */
        boolean isRed = TheRightSideIsRed();
        if (isRed) {
            PointTurnUsingEncoders(10, 0.2); // turn right 5 degrees
        } else {
            PointTurnUsingEncoders(-10, 0.2); // turn left 5 degrees
        }
        driveForDistanceCM(5, 0.3); // drive forward 10cm
        driveForDistanceCM(-5, 0.3); // drive back 10cm
        if (isRed) {
            PointTurnUsingEncoders(-10, 0.2); // turn back 5 degrees
        } else {
            PointTurnUsingEncoders(10, 0.2); // turn back 5 degrees
        }
    }
    //--------------------End of Press the red beacon button --------------------//

    //-------------------- Press the blue beacon button --------------------//
    void pressTheBlueButton() throws InterruptedException {
        /*
        Now we need to pivot the robot to the left or right depending on which side is red and drive
        forward about 10 cm.
         */
        boolean isRed = TheRightSideIsRed();
        if (isRed) {
            PointTurnUsingEncoders(10, 0.2); // turn right 5 degrees
        } else {
            PointTurnUsingEncoders(-10, 0.2); // turn left 5 degrees
        }
        driveForDistanceCM(5, 0.2); // drive forward 10cm
        driveForDistanceCM(-5, 0.2); // drive back 10cm
        if (isRed) {
            PointTurnUsingEncoders(-10, 0.2); // turn back 5 degrees
        } else {
            PointTurnUsingEncoders(10, 0.2); // turn back 5 degrees
        }
    }

    boolean areBothSidesOfBeaconBlue() {
        /*
        We need to check both color sensors to see if they are both red.  If not, maybe we can come
        back and press the button again.
         */
        if (leftBeaconButtonIsBlue() && rightBeaconButtonIsBlue()) {
            return true; // means that beacon is solid red
        } else return false; // means that beacon is not solid red
    }
    //-------------------- End of Press the blue beacon button --------------------//


    /*
     * set both wheels speeds with one statement.
     */


    void setDriveWheelPower(double right, double left) {
        leftDriveMotor.setPower(Range.clip(left,-1.0,1.0));
        rightDriveMotor.setPower(Range.clip(right,-1.0,1.0));
    }


    /*
    * drives the robot straight until it finds a white line on the floor
     */
    void LocateWhiteLine() throws InterruptedException {
        odsValue = ods_Line.getRawLightDetected();
        while (odsValue < 0.5) {
            setDriveWheelPower(0.1, 0.1);
            odsValue = ods_Line.getRawLightDetected();
        }
        // we may not need to stopDrive here
//        stopDrive();
        driveForDistanceInches(2,0.2);
    }
    /*
     * Use encoder ticks to cause the robot to pivot at the center of the robot. It over shoots the
     * target angle since the robot coasts after the motors are turned off.
     * This will only work driving forward
     */

    void swingTurnRight(int TurnAngle,double setSpeed){
        int TicksToTurn = (int) Swing_angleToTicks(TurnAngle);

        int leftM_target = leftDriveMotor.getCurrentPosition();
        int rightM_target;
        rightM_target = rightDriveMotor.getCurrentPosition() - TicksToTurn;
        if (setSpeed > 0)
            rightM_target = rightDriveMotor.getCurrentPosition() + TicksToTurn;
        else
            rightM_target = rightDriveMotor.getCurrentPosition() - TicksToTurn;
        int startPosition = rightDriveMotor.getCurrentPosition();
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        leftDriveMotor.setTargetPosition(leftM_target);
        rightDriveMotor.setTargetPosition(rightM_target);
        leftDriveMotor.setPower(1);

        // this maybe should be changed to checking if we have gone past the target.
        while (rightDriveMotor.isBusy()) {
            drivePower = setDrivePower(startPosition, rightDriveMotor.getCurrentPosition(),
                    rightDriveMotor.getTargetPosition(), setTargetInches(3), setSpeed);
            rightDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
        }
        //sleep(100);
        rightDriveMotor.setPower(stop);
        leftDriveMotor.setPower(stop);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }
    void swingTurnLeft(int TurnAngle,double setSpeed){
        int TicksToTurn = (int) Swing_angleToTicks(TurnAngle);

        int rightM_target = rightDriveMotor.getCurrentPosition();
        int leftM_target;
        if (setSpeed > 0)
            leftM_target = rightDriveMotor.getCurrentPosition() + TicksToTurn;
        else
            leftM_target = rightDriveMotor.getCurrentPosition() - TicksToTurn;

        int startPosition = leftDriveMotor.getCurrentPosition();
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        leftDriveMotor.setTargetPosition(leftM_target);
        rightDriveMotor.setTargetPosition(rightM_target);
        rightDriveMotor.setPower(1);

        while (leftDriveMotor.isBusy()) {
            drivePower = setDrivePower(startPosition, leftDriveMotor.getCurrentPosition(),
                    leftDriveMotor.getTargetPosition(), setTargetInches(3), setSpeed);
            leftDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
        }
        //sleep(100);
        rightDriveMotor.setPower(stop);
        leftDriveMotor.setPower(stop);

        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);


    }

    double Swing_angleToTicks(double turnAngle) {
        /*
         * return number of encoder ticks per degrees turnAngle
         * set only one wheel to this value, set the other to maintain it's current position
         * 14.45 is the radius of the arc the wheel will travel and 3 is the diameter of
         * the wheels.
         */
        double WheelDiameter = 3;
        double robotDiameter = 14.45*2; // with one wheel turning we need to double the diameter
        double robotCircumference = (robotDiameter * Math.PI);
        double wheelCircumference = (WheelDiameter * Math.PI);
        // return (robot Circumference / Wheel circumference) / 360 = distance travel per degree
        // then multiply it by the turn angle * Ticks per wheel revolution = motor ticks
        return Math.round(((robotCircumference / wheelCircumference / 360) * turnAngle) * driveWheelTicksPerRevolution);
    }


    void SwingTurnUsingEncoders(int TurnAngle, double SetSpeed) throws InterruptedException{
        int TicksToTurn = (int) wheel_angleToTicks(TurnAngle);

        int LeftM_Target = leftDriveMotor.getCurrentPosition() - TicksToTurn;
        int rightM_Target = leftDriveMotor.getCurrentPosition() + TicksToTurn;
        int StartPosition_left = leftDriveMotor.getCurrentPosition();
        int StartPosition_right = rightDriveMotor.getCurrentPosition();
        int StartPosition;
        int CurrentOps;
        int TargetOps;
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        leftDriveMotor.setTargetPosition(LeftM_Target);
        rightDriveMotor.setTargetPosition(rightM_Target);

        if (TurnAngle > 0) {
            StartPosition = StartPosition_left;
            CurrentOps = leftDriveMotor.getCurrentPosition();
            TargetOps = leftDriveMotor.getTargetPosition();

        } else {
            StartPosition = StartPosition_right;
            CurrentOps = rightDriveMotor.getCurrentPosition();
            TargetOps = rightDriveMotor.getTargetPosition();

        }

        boolean done = false;
        while(rightDriveMotor.isBusy() && leftDriveMotor.isBusy()) {
            drivePower = setDrivePower(StartPosition, CurrentOps, TargetOps, slowZone, (SetSpeed*2));
            if (TurnAngle > 0)
                leftDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
            else
                rightDriveMotor.setPower(-Range.clip(drivePower,-1.0,1.0));
        }
        sleep(100);

        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    /*
     * Use encoder ticks to cause the robot to pivot at the center of the robot. It over shoots the
     * target angle since the robot coasts after the motors are turned off.
     */
    void PointTurnUsingEncoders(int TurnAngle, double setSpeed) throws InterruptedException {
        int TicksToTurn = (int) wheel_angleToTicks(TurnAngle);

        int leftM_target = leftDriveMotor.getCurrentPosition() + TicksToTurn;
        int rightM_target = rightDriveMotor.getCurrentPosition() - TicksToTurn;
        int startPosition = leftDriveMotor.getCurrentPosition();
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        leftDriveMotor.setTargetPosition(leftM_target);
        rightDriveMotor.setTargetPosition(rightM_target);

        boolean done = false;
        while (rightDriveMotor.isBusy() && leftDriveMotor.isBusy()) {
            drivePower = setDrivePower(startPosition, leftDriveMotor.getCurrentPosition(),
                    leftDriveMotor.getTargetPosition(), setTargetInches(3), setSpeed);
            leftDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
            rightDriveMotor.setPower(-Range.clip(drivePower,-1.0,1.0));
        }
        //sleep(100);
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    /*
     * converts centimeters to inches for the driveForDistanceInches routine.
     */
    void driveForDistanceCM(double Centimeters, double setSpeed) throws InterruptedException {
        driveForDistanceInches(Centimeters / 2.54, setSpeed);  // convert centimeters to inches 2.54 cm = 1 inch
    }

    /*
     * Drive the robot in a somewhat straight line for "driveToDistance" inches.  It converts inches
     * to encoder ticks to determine where to stop.
     */
    void driveForDistanceInches(double driveToDistance, double setSpeed) throws InterruptedException {
        int startPosition;
        ticksToMove = -setTargetInches(driveToDistance);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        startPosition = leftDriveMotor.getCurrentPosition();

        leftDriveMotor.setTargetPosition(leftDriveMotor.getCurrentPosition() - ticksToMove);
        rightDriveMotor.setTargetPosition(rightDriveMotor.getCurrentPosition() - ticksToMove);

        while (rightDriveMotor.isBusy() && leftDriveMotor.isBusy()) {
            drivePower = setDrivePower(startPosition, leftDriveMotor.getCurrentPosition(),
                    leftDriveMotor.getTargetPosition(), slowZone, setSpeed);

            leftDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
            rightDriveMotor.setPower(Range.clip(drivePower,-1.0,1.0));
        }
        sleep(100);
        rightDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftDriveMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    double wheel_angleToTicks(double turnAngle) {
        /*
         * return number of encoder ticks per degree
         * set left negative of this value set right positive of this value
         * 14.45 is the diameter of the arc that the wheels will travel in and 3 is the diameter of
         * the wheels.
         */
        double robotRadius = (14.45 * Math.PI);
        double wheelRadius = (3 * Math.PI);
        return Math.round(((robotRadius / wheelRadius / 360) * turnAngle) * driveWheelTicksPerRevolution);
        //return turnAngle = Math.round((((14.5 * Math.PI) / (3 * Math.PI)) / 360) * driveWheelTicksPerRevolution);
    }


    /*
     * Convert inches to encoder ticks for the wheel motors.
     */
    public int setTargetInches(double distance) {
        /*motor ticks per revolution times distance per revolution*/
        return (int) (distance * driveWheelTicksPerInch);
    }

    public double getLeftUltrasonicSensorValue() {  // ignores 0 values and sets a valid distance (cm)
        double ultrasonicSensorValue = (int) left_sonar.getUltrasonicLevel();
        int I = 0;
        while (I < 10 && ultrasonicSensorValue == 0) {
            I++;
            ultrasonicSensorValue = (int) left_sonar.getUltrasonicLevel();
        }  // Hopefully we get a non zero value in 10 tries
        return ultrasonicSensorValue;
    }

    /*
     * getLeftUltrasonicSensorValue & getRightUltrasonicSensorValue
     * The lego ultrasonic sensor returns zero readings some of the time.  We drop them out to
     * get accurate readings.  Only 1 ultrasonic Sensor in the room at one time makes these about
     * useless.
     */

    public double getRightUltrasonicSensorValue() {  // ignores 0 values and sets a valid distance (cm)
        double ultrasonicSensorValue = (int) right_sonar.getUltrasonicLevel();
        int I = 0;
        while (I < 10 && ultrasonicSensorValue == 0) {
            I++;
            ultrasonicSensorValue = (int) right_sonar.getUltrasonicLevel();
        }  // Hopefully we get a non zero value in 10 tries
        return ultrasonicSensorValue;
    }

    public boolean rightBeaconButtonIsRed() {
        /*
        Check the right color sensor to determine if the Right side of the beacon is red.  If it is
        return true;
        */
        if (left_color.red() > left_color.blue() && left_color.red() > left_color.green()) {
            return false; // return true if the right color sensor "sees" red
        } else return true; // otherwise, return false
    }

    public boolean leftBeaconButtonIsRed() {
        /*
        Check the left color sensor to determine if the Left side of the beacon is red.  If it is
        return true;
        */
        if (left_color.red() > left_color.blue() && left_color.red() > left_color.green()) {
            return true; // return true if the left color sensor "sees" red
        } else return false; // otherwise, return false
    }


    public boolean rightBeaconButtonIsBlue() {
        /*
        Check the right color sensor to determine if the Right side of the beacon is red.  If it is
        return true;
        */
        if (right_color.blue() > right_color.red() && right_color.blue() > right_color.green()) {
            return true; // return true if the right color sensor "sees" red
        } else return false; // otherwise, return false
    }

    public boolean leftBeaconButtonIsBlue() {
        /*
        Check the left color sensor to determine if the Left side of the beacon is red.  If it is
        return true;
        */
        if (left_color.blue() > left_color.red() && left_color.blue() > left_color.green()) {
            return true; // return true if the left color sensor "sees" red
        } else return false; // otherwise, return false
    }


    /*
     *  calibrateCatapult will run the catapult until the micro switch is contacted.
     *  at this point the catapult is calibrated and ready for action.
     *  This routine was to be used with encoders.  The motor encoders are not consistent enough
     *  on the motor we used for the catapult rely on them to stop at the same position every time.
     */
    public void calibrateCatapult() {
        if (catapultCalibrate.isPressed()) {
        } else {
            // run the motor until we reach the reset point, then stopDrive the motor.
            while (!catapultCalibrate.isPressed()) {
                catapult.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                catapult.setPower(0.5);
            }
            catapult.setPower(0); // stopDrive the motor
            catapult.setMode(DcMotor.RunMode.RUN_TO_POSITION);
            // at this point the motor should be positioned just prior to launch.

        }

    }

    /***
     * waitForTick implements a periodic delay. However, this acts like a metronome with a regular
     * periodic tick.  This is used to compensate for varying processing times for each cycle.
     * The function looks at the elapsed cycle time, and sleeps for the remaining time interval.
     *
     * @param periodMs Length of wait cycle in mSec.
     * @throws InterruptedException
     */
    public void waitForTick(long periodMs) throws InterruptedException {

        long remaining = periodMs - (long) period.milliseconds();

        // sleep for the remaining portion of the regular cycle period.
        if (remaining > 0)
            sleep(remaining);

        // Reset the cycle clock for the next pass.
        period.reset();
    }
}
