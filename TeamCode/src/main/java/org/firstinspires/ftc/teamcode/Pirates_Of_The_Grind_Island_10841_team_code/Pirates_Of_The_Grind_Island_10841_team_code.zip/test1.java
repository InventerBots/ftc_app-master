package org.firstinspires.ftc.teamcode.Pirates_Of_The_Grind_Island_10841_team_code;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

/**
 * Created by Luke on 12/8/2016.
 */
@Autonomous(name = "Autonomous xxxx (red)", group = "10841 robot")
@Disabled

public class test1 extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {

    }
}
